package com.example.feijibook.helper;

// item 移动后触发
public interface OnItemMoveListener {
    void onItemMove(int fromPosition, int toPosition);
}
