package com.example.feijibook.activity.base.todo_mvp_base_interface;

/**
 * Created by 你是我的 on 2019/3/11
 */
public interface BasePresenter {
    void start();
    /**
     * 设置初始化view和控件的数据
     */
    void setInit();

}
